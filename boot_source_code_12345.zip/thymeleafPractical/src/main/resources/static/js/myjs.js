console.log("this is message on console")
//alert("js is activated")